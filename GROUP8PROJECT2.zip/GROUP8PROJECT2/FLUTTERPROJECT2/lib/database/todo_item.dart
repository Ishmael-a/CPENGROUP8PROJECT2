class ToDoItem{
  static String table = 'todo';

  int id;
  int user_id;
  String title;
  String status;

  ToDoItem({
    required this.id,
    required this.user_id,
    required this.title,
    required this.status
});

  Map<String, dynamic> toMap(){
    Map<String, dynamic> map = {
      'user_id': user_id
    };
    return map;
  }

  static ToDoItem fromMap(Map<String, dynamic> map){
    return ToDoItem(
      id: map['id'],
      user_id: map['user_id'],
      title: map['title'],
      status: map['status']
    );
  }
}